//Variables to replace
const poolId = '[UserPoolId]'
const clientId = '[AppClientId]'
const api = '[ApiURL]'

const Config = {
    UserPoolId: poolId,
    AppClientId: clientId,
    ApiURL: api + '/notes'
}

export default Config